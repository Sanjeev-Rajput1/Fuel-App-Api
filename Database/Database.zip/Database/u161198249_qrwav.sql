-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 07, 2024 at 07:06 AM
-- Server version: 10.11.8-MariaDB-cll-lve
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u161198249_qrwav`
--

-- --------------------------------------------------------

--
-- Table structure for table `addresses`
--

CREATE TABLE `addresses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(255) NOT NULL,
  `delivery_address` varchar(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `type_of_industry` varchar(255) NOT NULL,
  `storage_type` varchar(255) NOT NULL,
  `other_specify` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `addresses`
--

INSERT INTO `addresses` (`id`, `user_id`, `type`, `delivery_address`, `company_name`, `contact_number`, `type_of_industry`, `storage_type`, `other_specify`, `created_at`, `updated_at`) VALUES
(2, 2, 'primary', 'street Mohali', 'ghh', '1234566', 'IT', 'Other', NULL, '2024-07-29 09:17:20', '2024-08-01 03:38:55');

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `company_info`
--

CREATE TABLE `company_info` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `tin_number` varchar(255) DEFAULT NULL,
  `company_address` varchar(255) DEFAULT NULL,
  `company_email` varchar(255) DEFAULT NULL,
  `company_contact_number` varchar(255) DEFAULT NULL,
  `upload_bir` varchar(255) DEFAULT NULL,
  `upload_sec` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `company_info`
--

INSERT INTO `company_info` (`id`, `user_id`, `company_name`, `tin_number`, `company_address`, `company_email`, `company_contact_number`, `upload_bir`, `upload_sec`, `created_at`, `updated_at`) VALUES
(1, 1, 'baseline_it', '76676766776', 'ch moh', 'baselineit@gmail.com', '45678913', '[\"https://sitee.com\",\"https://site2.com\"]', '[\"https://section.com\",\"https://section2.com\"]', '2024-07-26 08:32:47', '2024-07-29 08:06:06'),
(2, 2, 'baseline_it_info_MOhali', '456123789', 'palampur', 'baseline@gmail.com', '45678913', '[\"https://site.com\",\"https://site2.com\"]', '[\"https://sec.com\",\"https://sec2.com\"]', '2024-07-29 03:17:32', '2024-07-29 03:17:32');

-- --------------------------------------------------------

--
-- Table structure for table `drivers`
--

CREATE TABLE `drivers` (
  `id` int(20) NOT NULL,
  `driver_category` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `expiration_date` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `address` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `upload_valid_id` varchar(255) NOT NULL,
  `vehicle_details` varchar(255) NOT NULL,
  `license_number` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `drivers`
--

INSERT INTO `drivers` (`id`, `driver_category`, `first_name`, `last_name`, `expiration_date`, `email`, `mobile`, `address`, `password`, `upload_valid_id`, `vehicle_details`, `license_number`, `status`, `latitude`, `longitude`, `created_at`, `updated_at`) VALUES
(2, 'OnRoad', 'Amy', 'Ford', '10-05-2020', 'amy@gmail.copm', '7012345654', 'Mohali', '$2y$12$uhUJQn44ChykW7h0Gm65JumIZHCYy6REErfdqoiuJt9450NpYcG1i', '[\"https://site.com\",\"https://site2.com\"]', 'Truck Union Chandigarh', 'asdf123456adf', 'available', 'ytty', 'eret', '2024-08-02 02:05:29', '2024-08-05 07:40:24'),
(3, 'In_Home', 'Amy', 'Ford', '10-05-2020', 'amy132@gmail.copm', '7012345654', 'Mohali', '$2y$12$4KMXo5E3XdW3PCMprVK8Q./SGfbIvHp6yaksVs2q7rZmcrLFb6GuC', '[\"https://site.com\",\"https://site2.com\"]', 'pb-12-08-10', 'fasdf12346', NULL, '', '', '2024-08-02 10:38:52', '2024-08-02 10:38:52'),
(4, 'In_Home', 'Amy', 'Ford', '10-05-2020', 'amy132fdf@gmail.copm', '7012345654', 'Mohali', '$2y$12$roNzkdXJTh1Y3mdW8n6UdutRImvMql69dk6/9jNYzbjIJkoWJsUne', '[\"https://site.com\",\"https://site2.com\"]', 'pb-12-08-10', 'fasdf12346', NULL, '', '', '2024-08-02 10:40:18', '2024-08-02 10:40:18');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `message` text NOT NULL,
  `rating` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `user_id`, `message`, `rating`, `created_at`, `updated_at`) VALUES
(1, 2, 'how are you', 3, '2024-08-02 07:58:50', '2024-08-02 07:58:50'),
(2, 2, 'how are you', 3, '2024-08-05 03:11:08', '2024-08-05 03:11:08');

-- --------------------------------------------------------

--
-- Table structure for table `fuel_delivery`
--

CREATE TABLE `fuel_delivery` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `fuel_type` varchar(255) NOT NULL,
  `quantity` decimal(8,2) NOT NULL,
  `location` varchar(255) NOT NULL,
  `preferred_time` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `fuel_delivery`
--

INSERT INTO `fuel_delivery` (`id`, `user_id`, `fuel_type`, `quantity`, `location`, `preferred_time`, `status`, `created_at`, `updated_at`) VALUES
(1, 2, 'yaa', 7.00, 'mohali', '54', 'cancelled', '2024-08-01 06:56:19', '2024-08-01 07:28:55'),
(2, 2, 'yaa', 7.00, 'mohali', '54', 'cancelled', '2024-08-01 06:58:22', '2024-08-01 08:23:41'),
(3, 2, 'yaa', 76.00, 'mohali', '5:49', 'null', '2024-08-01 07:30:33', '2024-08-01 07:30:33'),
(4, 2, 'yaa', 76.00, 'mohali', '5:49', 'cancelled', '2024-08-01 07:53:57', '2024-08-01 08:24:01'),
(5, 2, 'yaa', 76.00, 'mohali', '5:49', 'cancelled', '2024-08-01 07:54:10', '2024-08-01 08:24:09'),
(6, 2, 'yaa', 76.00, 'mohali', '5:49', 'pending', '2024-08-01 08:40:24', '2024-08-01 08:40:24'),
(7, 2, 'yaa', 76.00, 'mohali', '5:49', 'pending', '2024-08-01 09:47:50', '2024-08-01 09:47:50'),
(8, 2, 'yaa', 76.00, 'mohali', '5:49', 'pending', '2024-08-05 07:26:07', '2024-08-05 07:26:07');

-- --------------------------------------------------------

--
-- Table structure for table `fuel_purchases`
--

CREATE TABLE `fuel_purchases` (
  `id` int(20) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `fuel_type` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `supplier_id` varchar(255) NOT NULL,
  `date` varchar(50) NOT NULL,
  `created_at` varchar(50) NOT NULL DEFAULT current_timestamp(),
  `updated_at` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `fuel_purchases`
--

INSERT INTO `fuel_purchases` (`id`, `user_id`, `fuel_type`, `quantity`, `price`, `supplier_id`, `date`, `created_at`, `updated_at`) VALUES
(1, 2, 'OIl', '55', '7789', '1234', '12-08-2024', '2024-08-02 08:12:45', '2024-08-02 08:12:45'),
(2, 2, 'OIl', '55', '7789', '1235', '12-08-2024', '2024-08-02 10:15:44', '2024-08-02 10:15:44'),
(3, 2, 'OIl', '55', '7789', '1236', '12-08-2024', '2024-08-02 10:24:55', '2024-08-02 10:24:55'),
(4, 2, 'indian oil', '55', '7789', '1237', '2024-08-02', '2024-08-05 04:09:04', '2024-08-05 04:09:04'),
(5, 2, 'indian oil', '55', '7789', '1232', '2024-08-02', '2024-08-05 04:09:53', '2024-08-05 04:09:53'),
(6, 2, 'yes', '55', '7789', '123', '2024-08-02', '2024-08-05 04:22:36', '2024-08-05 04:22:36'),
(7, 2, 'yes', '55', '7789', '123', '2024-12-03', '2024-08-05 04:34:54', '2024-08-05 04:34:54'),
(8, 2, 'yes', '55', '7789', '123', '2024-12-03', '2024-08-05 04:40:38', '2024-08-05 04:40:38'),
(9, 2, 'OIl', '55', '7789', '123', '12-08-2024', '2024-08-05 07:20:05', '2024-08-05 07:20:05'),
(10, 2, 'OIl', '55', '7789', '123', '12-08-2024', '2024-08-05 07:22:20', '2024-08-05 07:22:20'),
(11, 2, 'OIl', '55', '7789', '123', '12-08-2024', '2024-08-05 07:26:29', '2024-08-05 07:26:29');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `fuel_type` varchar(255) NOT NULL,
  `quantity` bigint(20) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `source` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`id`, `user_id`, `fuel_type`, `quantity`, `date`, `source`, `created_at`, `updated_at`) VALUES
(1, 2, 'yes', 4, '2024-08-02', 'oil', '2024-08-02 04:35:24', '2024-08-02 05:03:47'),
(2, 2, 'nexus', 6, '2024-12-03', 'oil', '2024-08-02 04:40:09', '2024-08-02 05:06:09'),
(3, 2, 'indian oil', 3, '2024-05-05', 'oil', '2024-08-05 03:54:38', '2024-08-05 03:54:38'),
(4, 2, 'jio', 3, '2024-05-05', 'oil', '2024-08-05 03:54:51', '2024-08-05 03:54:51');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `id` int(11) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `created_at` varchar(50) NOT NULL DEFAULT current_timestamp(),
  `updated_at` varchar(50) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`id`, `user_id`, `name`, `path`, `url`, `created_at`, `updated_at`) VALUES
(1, NULL, '1722332202.jpg', '/uploads/1722332202.jpg', 'https://petro.bigfourglobalsystems.com/uploads/1722332202.jpg', '2024-07-30 09:36:42', '2024-07-30 09:36:42'),
(4, NULL, '1722333297.jpg', '/media/1722333297.jpg', 'https://petro.bigfourglobalsystems.com/media/1722333297.jpg', '2024-07-30 09:54:57', '2024-07-30 09:54:57'),
(7, NULL, '1722335879.jpg', '/media/1722335879.jpg', 'https://petro.bigfourglobalsystems.com/media/1722335879.jpg', '2024-07-30 10:37:59', '2024-07-30 10:37:59'),
(8, NULL, '1722390149.jpg', '/media/1722390149.jpg', 'https://petro.bigfourglobalsystems.com/media/1722390149.jpg', '2024-07-31 01:42:29', '2024-07-31 01:42:29'),
(9, NULL, '1722390762.jpg', '/media/1722390762.jpg', 'https://petro.bigfourglobalsystems.com/media/1722390762.jpg', '2024-07-31 01:52:42', '2024-07-31 01:52:42'),
(11, NULL, '1722391738.jpg', '/media/1722391738.jpg', 'https://petro.bigfourglobalsystems.com/media/1722391738.jpg', '2024-07-31 02:08:58', '2024-07-31 02:08:58'),
(12, NULL, '1722392919.jpg', '/media/1722392919.jpg', 'https://petro.bigfourglobalsystems.com/media/1722392919.jpg', '2024-07-31 02:28:39', '2024-07-31 02:28:39'),
(14, NULL, '1722393555_66a9a3d3432d5.jpg', '/media/1722393555_66a9a3d3432d5.jpg', 'https://petro.bigfourglobalsystems.com/media/1722393555_66a9a3d3432d5.jpg', '2024-07-31 02:39:15', '2024-07-31 02:39:15'),
(15, NULL, '1722393825_66a9a4e1511a8.jpg', '/media/1722393825_66a9a4e1511a8.jpg', 'https://petro.bigfourglobalsystems.com/media/1722393825_66a9a4e1511a8.jpg', '2024-07-31 02:43:45', '2024-07-31 02:43:45'),
(16, NULL, '1722393960_66a9a5681339d.jpg', '/media/1722393960_66a9a5681339d.jpg', 'https://petro.bigfourglobalsystems.com/media/1722393960_66a9a5681339d.jpg', '2024-07-31 02:46:00', '2024-07-31 02:46:00'),
(23, NULL, '1722395181.jpg', '/media/1722395181.jpg', 'https://petro.bigfourglobalsystems.com/media/1722395181.jpg', '2024-07-31 03:06:21', '2024-07-31 03:06:21'),
(24, NULL, '1722395685.jpg', '/media/1722395685.jpg', 'https://petro.bigfourglobalsystems.com/media/1722395685.jpg', '2024-07-31 03:14:45', '2024-07-31 03:14:45'),
(26, NULL, '1722395750.jpg', '/media/1722395750.jpg', 'https://petro.bigfourglobalsystems.com/media/1722395750.jpg', '2024-07-31 03:15:50', '2024-07-31 03:15:50'),
(28, NULL, '1722396583.jpg', '/media/1722396583.jpg', 'https://petro.bigfourglobalsystems.com/media/1722396583.jpg', '2024-07-31 03:29:43', '2024-07-31 03:29:43'),
(29, NULL, '1722397898.jpg', '/media/1722397898.jpg', 'https://petro.bigfourglobalsystems.com/media/1722397898.jpg', '2024-07-31 03:51:38', '2024-07-31 03:51:38'),
(31, NULL, '1722399152.jpg', '/media/1722399152.jpg', 'https://petro.bigfourglobalsystems.com/media/1722399152.jpg', '2024-07-31 04:12:32', '2024-07-31 04:12:32'),
(32, NULL, '1722399763.jpg', '/media/1722399763.jpg', 'https://petro.bigfourglobalsystems.com/media/1722399763.jpg', '2024-07-31 04:22:43', '2024-07-31 04:22:43'),
(33, NULL, '1722400605.jpg', '/media/1722400605.jpg', 'https://petro.bigfourglobalsystems.com/media/1722400605.jpg', '2024-07-31 04:36:45', '2024-07-31 04:36:45'),
(42, NULL, '1722478456.jpg', '/media/1722478456.jpg', 'https://petro.bigfourglobalsystems.com/media/1722478456.jpg', '2024-08-01 02:14:16', '2024-08-01 02:14:16'),
(44, NULL, '1722479251.jpg', '/media/1722479251.jpg', 'https://petro.bigfourglobalsystems.com/media/1722479251.jpg', '2024-08-01 02:27:31', '2024-08-01 02:27:31'),
(45, 2, '1722479407.jpg', '/media/1722479407.jpg', 'https://petro.bigfourglobalsystems.com/media/1722479407.jpg', '2024-08-01 02:30:07', '2024-08-01 02:30:07'),
(46, 2, '1722479833.jpg', '/media/1722479833.jpg', 'https://petro.bigfourglobalsystems.com/media/1722479833.jpg', '2024-08-01 02:37:13', '2024-08-01 02:37:13'),
(47, 2, '1722480310.jpg', '/media/1722480310.jpg', 'https://petro.bigfourglobalsystems.com/media/1722480310.jpg', '2024-08-01 02:45:10', '2024-08-01 02:45:10'),
(48, 2, '1722481047.jpg', '/media/1722481047.jpg', 'https://petro.bigfourglobalsystems.com/media/1722481047.jpg', '2024-08-01 02:57:27', '2024-08-01 02:57:27'),
(49, 2, '1722481079.jpg', '/media/1722481079.jpg', 'https://petro.bigfourglobalsystems.com/media/1722481079.jpg', '2024-08-01 02:57:59', '2024-08-01 02:57:59'),
(50, 2, '1722481450.jpg', '/media/1722481450.jpg', 'https://petro.bigfourglobalsystems.com/media/1722481450.jpg', '2024-08-01 03:04:10', '2024-08-01 03:04:10'),
(51, 2, '1722481474.jpg', '/media/1722481474.jpg', 'https://petro.bigfourglobalsystems.com/media/1722481474.jpg', '2024-08-01 03:04:34', '2024-08-01 03:04:34');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2024_07_25_071320_create_company_info_table', 1),
(5, '2024_07_25_105316_create_personal_access_tokens_table', 1),
(6, '2024_07_26_035933_create_delivery_info_table', 1),
(7, '2024_07_26_073104_update_company_info_table', 2),
(8, '2024_07_26_073831_update_company_info_table', 3),
(9, '2024_07_30_034900_media', 4),
(10, '2024_08_01_044258_create_fuel_delivery_table', 5),
(11, '2024_08_01_064022_create_driver_table', 6),
(12, '2024_08_02_030922_create_inventory_table', 6),
(14, '2024_08_02_070956_create_feedback_table', 7),
(15, '2024_08_02_091910_create_notifications_table', 8);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `title`, `message`, `is_read`, `created_at`, `updated_at`) VALUES
(1, 2, 'Notification', 'how are you', 1, '2024-08-02 14:56:10', '2024-08-05 07:15:46'),
(2, 2, 'Notification', 'i am good ', 0, '2024-08-02 14:56:10', '2024-08-02 14:56:10');

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES
(1, 'App\\Models\\User', 1, 'API Token', 'e9aaace35c0f8c5c71ed4ae1e319a0a5fdeec3e48dc63eeb47c23afa49ada6e1', '[\"*\"]', NULL, NULL, '2024-07-26 07:12:23', '2024-07-26 07:12:23'),
(2, 'App\\Models\\User', 1, 'API Token', '95bc2e409daed823a74a45ff912a48d38577c45d54803d88ccb38cc19da8def9', '[\"*\"]', '2024-07-29 08:06:06', NULL, '2024-07-26 07:12:41', '2024-07-29 08:06:06'),
(3, 'App\\Models\\User', 2, 'API Token', 'b51405922340ffd8a0a347a92efc65e5809c2592a698584ee9f9aea499a20fe8', '[\"*\"]', NULL, NULL, '2024-07-26 09:03:31', '2024-07-26 09:03:31'),
(4, 'App\\Models\\User', 2, 'API Token', 'b7f5e001f6d5064839737dfec36bf19a35d5deb99d1864e1077b198a446ec08d', '[\"*\"]', '2024-07-26 09:10:18', NULL, '2024-07-26 09:03:41', '2024-07-26 09:10:18'),
(5, 'App\\Models\\User', 2, 'API Token', '60c4169f979911c2834e80ced9d087993c5f47f5ebfc6abbbcc421fbafa67582', '[\"*\"]', NULL, NULL, '2024-07-29 03:13:27', '2024-07-29 03:13:27'),
(6, 'App\\Models\\User', 2, 'API Token', 'c93236a6bfbeee985509b25114795d341d7e111a80f35d3d989c90535e100f9e', '[\"*\"]', '2024-07-29 08:09:22', NULL, '2024-07-29 03:16:56', '2024-07-29 08:09:22'),
(7, 'App\\Models\\User', 2, 'API Token', 'eb0a5304cc947c75ffcf531eafeeea257de727586d0b7ffb760eeab2ffac2e10', '[\"*\"]', '2024-07-29 06:53:03', NULL, '2024-07-29 06:50:25', '2024-07-29 06:53:03'),
(8, 'App\\Models\\User', 1, 'API Token', '265fb3f5e95617509aa5bcac54ceabceb2b902bdd065ab401c696f092c5081a5', '[\"*\"]', '2024-07-29 08:13:04', NULL, '2024-07-29 06:54:42', '2024-07-29 08:13:04'),
(11, 'App\\Models\\User', 3, 'API Token', 'c31d625357ee62e8e791a8177ef0be3c37f3fde6a2ad984112104fc8dcf461c6', '[\"*\"]', NULL, NULL, '2024-07-29 07:42:26', '2024-07-29 07:42:26'),
(12, 'App\\Models\\User', 2, 'API Token', '2dc78b99dc5f674552b4857e4d8a199e1eb8f7e0103549ccc1f65378059d989d', '[\"*\"]', '2024-07-29 08:08:23', NULL, '2024-07-29 08:03:35', '2024-07-29 08:08:23'),
(13, 'App\\Models\\User', 2, 'API Token', 'f624982c22d48b6c519582f5cdf8c9d261e8025d17c96dab1d803ae0f1fd2401', '[\"*\"]', '2024-08-01 03:38:55', NULL, '2024-07-29 08:08:34', '2024-08-01 03:38:55'),
(14, 'App\\Models\\User', 2, 'API Token', '0027c1edb8031f50da309c8a1f5fba122f01637786691774937dff0dc31de7c0', '[\"*\"]', '2024-07-30 06:37:11', NULL, '2024-07-29 09:05:31', '2024-07-30 06:37:11'),
(15, 'App\\Models\\User', 2, 'API Token', 'a90bec2a6c6f718e3459dfcfabde8cd03def10500feed95031f9a890825a8f70', '[\"*\"]', '2024-08-01 03:37:55', NULL, '2024-07-29 11:46:43', '2024-08-01 03:37:55'),
(16, 'App\\Models\\User', 2, 'API Token', '8abf42731525bb15f87f578686916692aaa1fb138bbd99309d41a5e511a0c48d', '[\"*\"]', '2024-08-05 07:27:46', NULL, '2024-08-01 04:36:49', '2024-08-05 07:27:46'),
(18, 'App\\Models\\User', 2, 'API Token', '56d69ce2298cdbd82748c8ae569748e6dddff8f844f1322e9497ddc39e62e2b6', '[\"*\"]', NULL, NULL, '2024-08-01 09:15:04', '2024-08-01 09:15:04'),
(19, 'App\\Models\\User', 2, 'API Token', 'fa484274fe522263b4920231ef9c91cb08de7bc42d8619c33ef04e59d365540a', '[\"*\"]', NULL, NULL, '2024-08-01 09:15:11', '2024-08-01 09:15:11'),
(21, 'App\\Models\\User', 2, 'API Token', 'c8ad0e5ef4593b14f915c3ed8b22e704e80555601dfe9592f78d7c53491ea1c4', '[\"*\"]', '2024-08-05 07:25:10', NULL, '2024-08-01 09:33:06', '2024-08-05 07:25:10'),
(23, 'App\\Models\\Driver', 1, 'API Token', '72bb61c2e7d56edf8001718f7b65c64a2e2d563a7c86f9509f53b15660dc3b15', '[\"*\"]', '2024-08-01 09:36:07', NULL, '2024-08-01 09:35:44', '2024-08-01 09:36:07'),
(24, 'App\\Models\\Driver', 1, 'API Token', 'a0abc2315a816ff136090f67109bcdf908f176a8d72d214fae47943bb1fbd035', '[\"*\"]', '2024-08-01 10:14:43', NULL, '2024-08-01 09:54:04', '2024-08-01 10:14:43'),
(25, 'App\\Models\\Driver', 2, 'API Token', '6dbb56acfd72ae1329a954af634b31862d20210db720e75535213919ca76fcc1', '[\"*\"]', '2024-08-05 07:40:24', NULL, '2024-08-01 10:09:24', '2024-08-05 07:40:24'),
(26, 'App\\Models\\Driver', 1, 'API Token', '06d34a78ae21c762cd94d7f003af4b6fb6a68b08b7ac35daaa27461ec3fc7179', '[\"*\"]', '2024-08-01 10:14:25', NULL, '2024-08-01 10:11:24', '2024-08-01 10:14:25'),
(27, 'App\\Models\\Driver', 2, 'API Token', '6703d993e2d7e2539d8f42cf7dd40d252b341d8ca8ee1facb7fa6add2de3ab00', '[\"*\"]', '2024-08-05 07:23:37', NULL, '2024-08-02 04:16:24', '2024-08-05 07:23:37'),
(28, 'App\\Models\\User', 2, 'API Token', 'ef62770461492e6077668a8a715d9e3c7121c303df001ef5de713bb0cab3efd2', '[\"*\"]', '2024-08-05 07:15:46', NULL, '2024-08-02 04:20:22', '2024-08-05 07:15:46'),
(29, 'App\\Models\\User', 2, 'API Token', '68c3b68476692d601866dbb2eea482d0cc4a68fae674cf85814d92cdcea7b8e2', '[\"*\"]', NULL, NULL, '2024-08-02 06:22:36', '2024-08-02 06:22:36'),
(30, 'App\\Models\\Driver', 2, 'API Token', 'b9d4b84ada37138228803edd2061fc7cac98a94571db94d2fc62a16ce190743d', '[\"*\"]', NULL, NULL, '2024-08-02 07:11:40', '2024-08-02 07:11:40'),
(31, 'App\\Models\\Driver', 2, 'API Token', '94d4e3056e6fa6986b3bd39825a68139b68c45dbaf25d25c733f681bda12d780', '[\"*\"]', '2024-08-05 07:26:29', NULL, '2024-08-02 07:57:47', '2024-08-05 07:26:29'),
(32, 'App\\Models\\Driver', 2, 'API Token', '6ca2fdc79b588b63b18c7b7f061ea487fb749a4016e7fa7ef84bdc9f3aa80731', '[\"*\"]', '2024-08-05 04:15:55', NULL, '2024-08-05 04:15:26', '2024-08-05 04:15:55'),
(33, 'App\\Models\\User', 2, 'API Token', '7bf012763d36569717dfc35486cd6c1fbd09892bead5dc177525230764597e56', '[\"*\"]', '2024-08-05 07:26:34', NULL, '2024-08-05 04:21:10', '2024-08-05 07:26:34'),
(34, 'App\\Models\\Driver', 2, 'API Token', '90f08ebea4038af7a43f8dde8258ec1f8f155f309d8791bbd80ed32e8b79e851', '[\"*\"]', '2024-08-05 06:58:26', NULL, '2024-08-05 06:55:52', '2024-08-05 06:58:26');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tankers`
--

CREATE TABLE `tankers` (
  `tanker_id` int(20) NOT NULL,
  `driver_id` int(20) NOT NULL,
  `capacity` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `updated_at` varchar(50) NOT NULL DEFAULT current_timestamp(),
  `created_at` varchar(50) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tankers`
--

INSERT INTO `tankers` (`tanker_id`, `driver_id`, `capacity`, `status`, `updated_at`, `created_at`) VALUES
(1, 2, '100', 'Off Duty', '2024-08-05 03:42:46', '2024-08-02 04:54:31'),
(2, 2, '100', 'On Duty', '2024-08-05 05:06:37', '2024-08-05 05:06:37'),
(3, 2, '100', 'On Duty', '2024-08-05 07:22:43', '2024-08-05 07:22:43');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `position_in_company` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `agent_code` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `position_in_company`, `email`, `mobile`, `role`, `agent_code`, `password`, `created_at`, `updated_at`) VALUES
(1, 'sumit', 'sunny', 'AMO', 'suny@gmail.com', '7070701414', 'user', NULL, '$2y$12$XkzupEb7dId1INmh2xxqlO3dREc8ZUkhvtwWbyMO4p5I88veue1Jm', '2024-07-26 07:12:23', '2024-07-26 07:12:23'),
(2, 'sanjeev', 'rajput', 'AMO', 'sanjeev@gmail.com', '87365355333', 'user', NULL, '$2y$12$YZlgoGjAhyFzoesxupQ/DOqLJtg7wEPgy80r.MTDnlWY5/pqlLMTW', '2024-07-26 09:03:31', '2024-07-26 09:03:31'),
(3, 'Ahmed', 'sunny', 'AMO', 'ahmed@gmail.com', '7070701414', 'user', NULL, '$2y$12$oP/yQQFPCJRIucXKLmvhM.uIZyVlRuBJb/Ul214cAMxJ5/rCVwsMm', '2024-07-29 07:38:50', '2024-07-29 07:38:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addresses`
--
ALTER TABLE `addresses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `delivery_info_user_id_foreign` (`user_id`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `company_info`
--
ALTER TABLE `company_info`
  ADD PRIMARY KEY (`id`),
  ADD KEY `company_info_user_id_foreign` (`user_id`);

--
-- Indexes for table `drivers`
--
ALTER TABLE `drivers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`),
  ADD KEY `feedback_user_id_foreign` (`user_id`);

--
-- Indexes for table `fuel_delivery`
--
ALTER TABLE `fuel_delivery`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fuel_delivery_user_id_foreign` (`user_id`);

--
-- Indexes for table `fuel_purchases`
--
ALTER TABLE `fuel_purchases`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id fk` (`user_id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inventory_user_id_foreign` (`user_id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_user_id_foreign` (`user_id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `tankers`
--
ALTER TABLE `tankers`
  ADD PRIMARY KEY (`tanker_id`),
  ADD KEY `driver_id` (`driver_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addresses`
--
ALTER TABLE `addresses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `company_info`
--
ALTER TABLE `company_info`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `drivers`
--
ALTER TABLE `drivers`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `fuel_delivery`
--
ALTER TABLE `fuel_delivery`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `fuel_purchases`
--
ALTER TABLE `fuel_purchases`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `tankers`
--
ALTER TABLE `tankers`
  MODIFY `tanker_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `addresses`
--
ALTER TABLE `addresses`
  ADD CONSTRAINT `delivery_info_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `company_info`
--
ALTER TABLE `company_info`
  ADD CONSTRAINT `company_info_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `fuel_delivery`
--
ALTER TABLE `fuel_delivery`
  ADD CONSTRAINT `fuel_delivery_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `fuel_purchases`
--
ALTER TABLE `fuel_purchases`
  ADD CONSTRAINT `user_id fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `inventory`
--
ALTER TABLE `inventory`
  ADD CONSTRAINT `inventory_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `media`
--
ALTER TABLE `media`
  ADD CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `tankers`
--
ALTER TABLE `tankers`
  ADD CONSTRAINT `driver_id` FOREIGN KEY (`driver_id`) REFERENCES `drivers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
